﻿global using Microsoft.Extensions.Configuration;
global using Microsoft.Extensions.DependencyInjection;
global using Domain.Event;

global using Domain.UserDomain;
global using Microsoft.EntityFrameworkCore;
global using System.ComponentModel.DataAnnotations;
