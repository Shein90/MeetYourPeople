﻿namespace Domain.UserDomain;

public enum UserMeetingRole
{
    Owner,
    Participant
}
