﻿namespace Domain.Location;

public class AddressDto
{
    public int AddressID { get; set; }
    public required string AddressText { get; set; }
}
