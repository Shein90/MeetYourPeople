﻿global using Domain.UserDomain;
global using Domain.Event;
global using Domain.Location;